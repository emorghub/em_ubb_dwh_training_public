-- ===========================================================================
-- GENERATED for CR-ECB-001 from the delivery agreement CBS_SIM v1.1
--   (change-requests/CR-ECB-001/UBB_Delivery_Agreement_CBS_SIM_v1.1.docx), entity COLLATERAL, file CBS_SIM_COLLATERAL_YYYYMMDD.csv
--   by tools/codegen/generate_staging.py on 2026-11-18
--   agreement fingerprint 47cb8bbfff0f5daf, approved by Emil Angelov on 2026-11-18
--   asked for by change-requests/CR-ECB-001/UBB_Delivery_Agreement_CBS_SIM_v1.1.docx
-- Change the delivery agreement and regenerate - do not hand-edit this file.
-- ===========================================================================
--
-- Brings the existing UBB_STAGING2.STG_COLLATERAL in line with the agreement. Written by
-- comparing the agreement with the table script in sql/ on 2026-11-18.
-- New columns are nullable: the rows already loaded have no value for them.

ALTER TABLE UBB_STAGING2.STG_COLLATERAL ADD (
    ELIGIBILITY_FLAG       CHAR(1 CHAR),
    REGULATORY_HAIRCUT_PCT NUMBER(9,6)
);
COMMENT ON COLUMN UBB_STAGING2.STG_COLLATERAL.ELIGIBILITY_FLAG IS 'Whether collateral meets internal eligibility criteria. Allowed values: Y or N; never empty.';
COMMENT ON COLUMN UBB_STAGING2.STG_COLLATERAL.REGULATORY_HAIRCUT_PCT IS 'Haircut percentage applicable to recognized collateral value, as a percentage between 0 and 100. Never empty.';
