-- ===========================================================================
-- GENERATED for CR-ECB-001 from the delivery agreement RISK_ENGINE_SIM v1.0
--   (change-requests/CR-ECB-001/UBB_Delivery_Agreement_RISK_ENGINE_SIM_v1.0.docx), entity CREDIT_RISK_ASSESSMENT, file RISK_ENGINE_SIM_CREDIT_RISK_ASSESSMENT_YYYYMMDD.csv
--   by tools/codegen/generate_staging.py on 2026-11-18
--   agreement fingerprint 5ecf5da99f123a23, approved by Emil Angelov on 2026-11-18
--   asked for by change-requests/CR-ECB-001/UBB_Delivery_Agreement_RISK_ENGINE_SIM_v1.0.docx
-- Change the delivery agreement and regenerate - do not hand-edit this file.
-- ===========================================================================
--
-- Creates UBB_STAGING2.STG_CREDIT_RISK_ASSESSMENT, which receives the delivered file RISK_ENGINE_SIM_CREDIT_RISK_ASSESSMENT_YYYYMMDD.csv: one
-- column per attribute of the agreement, plus the warehouse columns every
-- staging table has (LOAD_ID first, STAGED_AT last). One partition per load.

CREATE TABLE UBB_STAGING2.STG_CREDIT_RISK_ASSESSMENT (
    LOAD_ID                NUMBER(18,0) NOT NULL,
    LOAN_REF               VARCHAR2(80 CHAR) NOT NULL,
    ASSESSMENT_DATE        DATE NOT NULL,
    PROBABILITY_OF_DEFAULT NUMBER(9,6),
    LOSS_GIVEN_DEFAULT     NUMBER(9,6),
    MODEL_VERSION          VARCHAR2(40 CHAR),
    STAGED_AT              TIMESTAMP(6) DEFAULT SYSTIMESTAMP NOT NULL,
    CONSTRAINT PK_STG_CREDIT_RISK_ASSESSMENT PRIMARY KEY (LOAD_ID, LOAN_REF, ASSESSMENT_DATE),
    CONSTRAINT FK_STG_CREDIT_RISK_ASSESSMENT_LOAD FOREIGN KEY (LOAD_ID) REFERENCES UBB_CORE2.CTRL_LOAD (LOAD_ID)
)
PARTITION BY LIST (LOAD_ID) AUTOMATIC (PARTITION P_LOAD_0 VALUES (0));

COMMENT ON TABLE UBB_STAGING2.STG_CREDIT_RISK_ASSESSMENT IS 'RISK_ENGINE_SIM CREDIT_RISK_ASSESSMENT daily delivery (RISK_ENGINE_SIM_CREDIT_RISK_ASSESSMENT_YYYYMMDD.csv), delivery agreement v1.0; business key LOAN_REF + ASSESSMENT_DATE.';
COMMENT ON COLUMN UBB_STAGING2.STG_CREDIT_RISK_ASSESSMENT.LOAN_REF IS 'Loan evaluated in this assessment. LOAN_REF + ASSESSMENT_DATE is unique within one delivery (one assessment of a loan per assessment date).';
COMMENT ON COLUMN UBB_STAGING2.STG_CREDIT_RISK_ASSESSMENT.ASSESSMENT_DATE IS 'Effective date of the risk parameter assessment';
COMMENT ON COLUMN UBB_STAGING2.STG_CREDIT_RISK_ASSESSMENT.PROBABILITY_OF_DEFAULT IS 'Estimated probability of default over the applicable risk horizon, as a fraction between 0 and 1. The horizon is 12 months.';
COMMENT ON COLUMN UBB_STAGING2.STG_CREDIT_RISK_ASSESSMENT.LOSS_GIVEN_DEFAULT IS 'Estimated proportion of exposure lost conditional on default, as a fraction between 0 and 1.';
COMMENT ON COLUMN UBB_STAGING2.STG_CREDIT_RISK_ASSESSMENT.MODEL_VERSION IS 'Identifier of the risk model version used for the assessment';

GRANT SELECT ON UBB_STAGING2.STG_CREDIT_RISK_ASSESSMENT TO UBB_CORE2;
