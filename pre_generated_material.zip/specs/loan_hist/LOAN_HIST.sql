-- ===========================================================================
-- GENERATED from mapping M_LOAN_HIST (specs/loan_hist/M_LOAN_HIST.xlsx)
--   by tools/codegen/generate.py on 2026-11-21
--   mapping fingerprint d50835be1545a80b, approved by Vladimir Andreev on 2026-11-21
-- Change the mapping workbook and regenerate - do not hand-edit this file.
-- ===========================================================================
--
-- Creates UBB_CORE2.LOAN_HIST as the mapping describes it: one column per row of the
-- workbook's Columns sheet, in that order, primary key = Business_Key.
-- This is the full, current definition of the table. For a table that already
-- exists, deploy the change script <MAPPING_ID>.sql instead of this one.

CREATE TABLE UBB_CORE2.LOAN_HIST (
    LOAN_ID                  NUMBER(18,0) NOT NULL,
    LOAD_ID                  NUMBER(18,0) NOT NULL,
    PARTNER_ID               NUMBER(18,0),
    LIMIT_ID                 NUMBER(18,0),
    LOAN_TYPE                VARCHAR2(30 CHAR),
    LOAN_STATUS              VARCHAR2(20 CHAR),
    CURRENCY_CODE            CHAR(3 CHAR) NOT NULL,
    PRINCIPAL_AMT            NUMBER(20,2) NOT NULL,
    UNDRAWN_AMT              NUMBER(20,2) NOT NULL,
    OVERDUE_AMT              NUMBER(20,2) NOT NULL,
    INTEREST_RATE            NUMBER(9,6),
    START_DATE               DATE,
    MATURITY_DATE            DATE,
    CREDIT_CONVERSION_FACTOR NUMBER(9,6),
    CREATED_AT               TIMESTAMP(6) NOT NULL,
    CONSTRAINT PK_LOAN_HIST PRIMARY KEY (LOAN_ID, LOAD_ID)
);

COMMENT ON TABLE UBB_CORE2.LOAN_HIST IS 'Full daily snapshot of the CBS loans: one row per loan and per accepted CBS loan load, with its partner and limit, amounts, dates and the credit conversion factor for the undrawn amount.';
COMMENT ON COLUMN UBB_CORE2.LOAN_HIST.LOAN_ID IS 'Loan ID: CORE surrogate identifier of the loan.';
COMMENT ON COLUMN UBB_CORE2.LOAN_HIST.LOAD_ID IS 'Load ID: Identifier of the CBS loan load (CTRL_LOAD) the snapshot comes from; it determines the business date.';
COMMENT ON COLUMN UBB_CORE2.LOAN_HIST.PARTNER_ID IS 'Partner ID: CORE identifier of the borrower: the CRM partner valid on the business date for the loan''s CBS partner reference.';
COMMENT ON COLUMN UBB_CORE2.LOAN_HIST.LIMIT_ID IS 'Limit ID: CORE identifier of the credit limit the loan is booked under; empty when the loan has no limit.';
COMMENT ON COLUMN UBB_CORE2.LOAN_HIST.LOAN_TYPE IS 'Loan type: Loan classification as delivered by the core banking system.';
COMMENT ON COLUMN UBB_CORE2.LOAN_HIST.LOAN_STATUS IS 'Loan status: Status of the loan on the business date, as delivered by the core banking system.';
COMMENT ON COLUMN UBB_CORE2.LOAN_HIST.CURRENCY_CODE IS 'Currency: ISO currency of the loan amounts.';
COMMENT ON COLUMN UBB_CORE2.LOAN_HIST.PRINCIPAL_AMT IS 'Outstanding principal: Outstanding principal of the loan in the loan currency. Includes any overdue amount (Q-01 of the requirements).';
COMMENT ON COLUMN UBB_CORE2.LOAN_HIST.UNDRAWN_AMT IS 'Undrawn amount: Committed but not yet drawn amount of the loan in the loan currency.';
COMMENT ON COLUMN UBB_CORE2.LOAN_HIST.OVERDUE_AMT IS 'Overdue amount: Part of the outstanding principal that is overdue, in the loan currency.';
COMMENT ON COLUMN UBB_CORE2.LOAN_HIST.INTEREST_RATE IS 'Interest rate: Contractual interest rate of the loan.';
COMMENT ON COLUMN UBB_CORE2.LOAN_HIST.START_DATE IS 'Start date: Date the loan starts.';
COMMENT ON COLUMN UBB_CORE2.LOAN_HIST.MATURITY_DATE IS 'Maturity date: Date the loan is due to be repaid.';
COMMENT ON COLUMN UBB_CORE2.LOAN_HIST.CREDIT_CONVERSION_FACTOR IS 'Credit conversion factor: Factor, as a fraction between 0 and 1, by which the undrawn amount of the loan is converted into an exposure equivalent. Gross exposure = outstanding principal + undrawn amount x this factor.';
COMMENT ON COLUMN UBB_CORE2.LOAN_HIST.CREATED_AT IS 'Created at: Technical timestamp of the moment the row was loaded.';
