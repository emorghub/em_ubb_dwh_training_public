-- ===========================================================================
-- GENERATED from mapping M_LOAN_HIST (specs/loan_hist/M_LOAN_HIST.xlsx)
--   by tools/codegen/generate.py on 2026-11-21
--   mapping fingerprint d50835be1545a80b, approved by Vladimir Andreev on 2026-11-21
-- Change the mapping workbook and regenerate - do not hand-edit this file.
-- ===========================================================================
--
-- utPLSQL tests for UBB_CORE2.LOAN_HIST: one test per acceptance criterion in the
-- mapping, plus a check that the test data actually reaches the load (so no
-- test can pass just because nothing was loaded).
-- A guard test loads the good data, adds the data that breaks the guard, and
-- expects the next run to be refused with the target left unchanged.
-- Test data lives in UT_LOAN_HIST_DATA (tests/UT_LOAN_HIST_DATA.sql), which the
-- generator writes once and never overwrites.
-- Every test runs inside a transaction utPLSQL rolls back afterwards
-- (--%rollback(auto)); that works because the load procedure never commits.
--
-- Running this file also runs the tests (last statement). Deploy the test data
-- package (UT_LOAN_HIST_DATA) first. To rerun later without redeploying:
--   EXEC ut.run('UBB_CORE2.UT_LOAN_HIST');

CREATE OR REPLACE PACKAGE UBB_CORE2.UT_LOAN_HIST AS
    --%suite(LOAN_HIST load - mapping M_LOAN_HIST)
    --%suitepath(ubb_core2)
    --%rollback(auto)

    --%beforeeach
    PROCEDURE seed;

    --%test(The test data gives the source query at least one row)
    PROCEDURE t_fixture_has_rows;

    --%test(AC01: No LOAN_ID and LOAD_ID occurs twice in LOAN_HIST.)
    PROCEDURE t_ac01;

    --%test(AC02: Every loan of the selected CBS loan load is in LOAN_HIST.)
    PROCEDURE t_ac02;

    --%test(AC03: Every loaded loan with an undrawn amount above 0 has a credit conversion factor.)
    PROCEDURE t_ac03;

    --%test(AC04: Every credit conversion factor in LOAN_HIST is between 0 and 1.)
    PROCEDURE t_ac04;

    --%test(AC05: The outstanding principal in LOAN_HIST equals the outstanding principal delivered in the CBS loan load of the date.)
    PROCEDURE t_ac05;

    --%test(AC06: Stop the run unless the business date is not empty and at midnight, and there is exactly one VALIDATED or COMPLETED CBS_SIM load of LOAN and of LIMIT for it.)
    PROCEDURE t_ac06;

    --%test(AC07: Stop the run when the CBS limit snapshot load of the date has not COMPLETED in the job run log.)
    PROCEDURE t_ac07;

    --%test(AC08: Stop the run when a loan of the load has no partner reference, currency, outstanding principal, undrawn amount or overdue amount.)
    PROCEDURE t_ac08;

    --%test(AC09: Stop the run when the CBS partner reference of a loan does not match exactly one CRM partner valid on the business date.)
    PROCEDURE t_ac09;

    --%test(AC10: Stop the run when a loan of the load has no row in UBB_CORE2.LOAN.)
    PROCEDURE t_ac10;

    --%test(AC11: Stop the run when a LIMIT_REF of a loan is not found exactly once in the limit snapshot of the date for the loan's partner.)
    PROCEDURE t_ac11;

    --%test(AC12: Stop the run when a loan has an undrawn amount above 0 and no credit conversion factor, or a factor outside 0 to 1.)
    PROCEDURE t_ac12;

    --%test(AC13: Stop the run if any LOAN_HIST row already exists for the selected CBS loan load.)
    PROCEDURE t_ac13;
END UT_LOAN_HIST;
/

CREATE OR REPLACE PACKAGE BODY UBB_CORE2.UT_LOAN_HIST AS

    -- The parameter values the load runs with, taken from the test data package
    -- so Check_SQL from the mapping can use them by name.
    P_BUSINESS_DATE CONSTANT DATE := UBB_CORE2.UT_LOAN_HIST_DATA.P_BUSINESS_DATE;

    PROCEDURE seed IS
    BEGIN
        UBB_CORE2.UT_LOAN_HIST_DATA.seed;
    END seed;

    PROCEDURE run_load IS
    BEGIN
        UBB_CORE2.PKG_ETL_LOAN_HIST.LOAD_DAY(P_BUSINESS_DATE => P_BUSINESS_DATE);
    END run_load;

    -- Row count and a content hash of the whole target, to compare two states of it.
    PROCEDURE measure(o_rows OUT INTEGER, o_hash OUT NUMBER) IS
    BEGIN
        SELECT COUNT(*), NVL(SUM(NVL(ORA_HASH(LOAN_ID), 0) + NVL(ORA_HASH(LOAD_ID), 0) + NVL(ORA_HASH(PARTNER_ID), 0) + NVL(ORA_HASH(LIMIT_ID), 0) + NVL(ORA_HASH(LOAN_TYPE), 0) + NVL(ORA_HASH(LOAN_STATUS), 0) + NVL(ORA_HASH(CURRENCY_CODE), 0) + NVL(ORA_HASH(PRINCIPAL_AMT), 0) + NVL(ORA_HASH(UNDRAWN_AMT), 0) + NVL(ORA_HASH(OVERDUE_AMT), 0) + NVL(ORA_HASH(INTEREST_RATE), 0) + NVL(ORA_HASH(START_DATE), 0) + NVL(ORA_HASH(MATURITY_DATE), 0) + NVL(ORA_HASH(CREDIT_CONVERSION_FACTOR), 0)), 0)
          INTO o_rows, o_hash
          FROM UBB_CORE2.LOAN_HIST;
    END measure;

    PROCEDURE t_fixture_has_rows IS
        l_rows INTEGER;
    BEGIN
        SELECT COUNT(*) INTO l_rows FROM (
            SELECT LOAN.LOAN_ID                      AS LOAN_ID,
                   STG_LOAN.LOAD_ID                  AS LOAD_ID,
                   PARTNER_HIST.PARTNER_ID           AS PARTNER_ID,
                   CREDIT_LIMIT.LIMIT_ID             AS LIMIT_ID,
                   STG_LOAN.LOAN_TYPE                AS LOAN_TYPE,
                   STG_LOAN.LOAN_STATUS              AS LOAN_STATUS,
                   STG_LOAN.CURRENCY_CODE            AS CURRENCY_CODE,
                   STG_LOAN.PRINCIPAL_AMT            AS PRINCIPAL_AMT,
                   STG_LOAN.UNDRAWN_AMT              AS UNDRAWN_AMT,
                   STG_LOAN.OVERDUE_AMT              AS OVERDUE_AMT,
                   STG_LOAN.INTEREST_RATE            AS INTEREST_RATE,
                   STG_LOAN.START_DATE               AS START_DATE,
                   STG_LOAN.MATURITY_DATE            AS MATURITY_DATE,
                   STG_LOAN.CREDIT_CONVERSION_FACTOR AS CREDIT_CONVERSION_FACTOR,
                   SYSTIMESTAMP                      AS CREATED_AT
            FROM UBB_STAGING2.STG_LOAN STG_LOAN
            JOIN UBB_CORE2.CTRL_LOAD CTRL_LOAD
              ON CTRL_LOAD.LOAD_ID = STG_LOAN.LOAD_ID
            JOIN UBB_CORE2.LOAN LOAN
              ON LOAN.SOURCE_SYSTEM = 'CBS_SIM' AND LOAN.LOAN_REF = STG_LOAN.LOAN_REF
            JOIN UBB_CORE2.PARTNER_HIST PARTNER_HIST
              ON PARTNER_HIST.CBS_PARTNER_REF = STG_LOAN.CBS_PARTNER_REF AND PARTNER_HIST.VALID_FROM <= P_BUSINESS_DATE AND PARTNER_HIST.VALID_TO > P_BUSINESS_DATE
            JOIN UBB_CORE2.PARTNER PARTNER
              ON PARTNER.PARTNER_ID = PARTNER_HIST.PARTNER_ID AND PARTNER.SOURCE_SYSTEM = 'CRM_SIM'
            LEFT JOIN UBB_CORE2.CREDIT_LIMIT CREDIT_LIMIT
              ON CREDIT_LIMIT.SOURCE_SYSTEM = 'CBS_SIM' AND CREDIT_LIMIT.LIMIT_REF = STG_LOAN.LIMIT_REF
            LEFT JOIN UBB_CORE2.LIMIT_HIST LIMIT_HIST
              ON LIMIT_HIST.LIMIT_ID = CREDIT_LIMIT.LIMIT_ID AND LIMIT_HIST.LOAD_ID = (SELECT CTRL_LOAD.LOAD_ID FROM CTRL_LOAD WHERE CTRL_LOAD.SOURCE_SYSTEM = 'CBS_SIM' AND CTRL_LOAD.DATASET_NAME = 'LIMIT' AND CTRL_LOAD.BUSINESS_DATE = P_BUSINESS_DATE AND CTRL_LOAD.LOAD_STATUS IN ('VALIDATED', 'COMPLETED'))
            WHERE CTRL_LOAD.SOURCE_SYSTEM = 'CBS_SIM' AND CTRL_LOAD.DATASET_NAME = 'LOAN' AND CTRL_LOAD.BUSINESS_DATE = P_BUSINESS_DATE AND CTRL_LOAD.LOAD_STATUS IN ('VALIDATED', 'COMPLETED') AND (STG_LOAN.LIMIT_REF IS NULL OR (LIMIT_HIST.LIMIT_ID IS NOT NULL AND LIMIT_HIST.PARTNER_ID = PARTNER_HIST.PARTNER_ID))
        );
        ut.expect(l_rows, 'source rows produced by the test data').to_be_greater_than(0);
    END t_fixture_has_rows;

    -- AC01 (unique_key): No LOAN_ID and LOAD_ID occurs twice in LOAN_HIST.
    PROCEDURE t_ac01 IS
        l_duplicates INTEGER;
    BEGIN
        run_load;
        SELECT COUNT(*) INTO l_duplicates FROM (
            SELECT LOAN_ID, LOAD_ID
            FROM UBB_CORE2.LOAN_HIST
            GROUP BY LOAN_ID, LOAD_ID
            HAVING COUNT(*) > 1
        );
        ut.expect(l_duplicates, 'business keys that occur more than once').to_equal(0);
    END t_ac01;

    -- AC02 (all_source_rows_loaded): Every loan of the selected CBS loan load is in LOAN_HIST.
    PROCEDURE t_ac02 IS
        l_missing INTEGER;
    BEGIN
        run_load;
        SELECT COUNT(*) INTO l_missing FROM (
            SELECT LOAN_ID, LOAD_ID FROM (
                SELECT LOAN.LOAN_ID                      AS LOAN_ID,
                       STG_LOAN.LOAD_ID                  AS LOAD_ID,
                       PARTNER_HIST.PARTNER_ID           AS PARTNER_ID,
                       CREDIT_LIMIT.LIMIT_ID             AS LIMIT_ID,
                       STG_LOAN.LOAN_TYPE                AS LOAN_TYPE,
                       STG_LOAN.LOAN_STATUS              AS LOAN_STATUS,
                       STG_LOAN.CURRENCY_CODE            AS CURRENCY_CODE,
                       STG_LOAN.PRINCIPAL_AMT            AS PRINCIPAL_AMT,
                       STG_LOAN.UNDRAWN_AMT              AS UNDRAWN_AMT,
                       STG_LOAN.OVERDUE_AMT              AS OVERDUE_AMT,
                       STG_LOAN.INTEREST_RATE            AS INTEREST_RATE,
                       STG_LOAN.START_DATE               AS START_DATE,
                       STG_LOAN.MATURITY_DATE            AS MATURITY_DATE,
                       STG_LOAN.CREDIT_CONVERSION_FACTOR AS CREDIT_CONVERSION_FACTOR,
                       SYSTIMESTAMP                      AS CREATED_AT
                FROM UBB_STAGING2.STG_LOAN STG_LOAN
                JOIN UBB_CORE2.CTRL_LOAD CTRL_LOAD
                  ON CTRL_LOAD.LOAD_ID = STG_LOAN.LOAD_ID
                JOIN UBB_CORE2.LOAN LOAN
                  ON LOAN.SOURCE_SYSTEM = 'CBS_SIM' AND LOAN.LOAN_REF = STG_LOAN.LOAN_REF
                JOIN UBB_CORE2.PARTNER_HIST PARTNER_HIST
                  ON PARTNER_HIST.CBS_PARTNER_REF = STG_LOAN.CBS_PARTNER_REF AND PARTNER_HIST.VALID_FROM <= P_BUSINESS_DATE AND PARTNER_HIST.VALID_TO > P_BUSINESS_DATE
                JOIN UBB_CORE2.PARTNER PARTNER
                  ON PARTNER.PARTNER_ID = PARTNER_HIST.PARTNER_ID AND PARTNER.SOURCE_SYSTEM = 'CRM_SIM'
                LEFT JOIN UBB_CORE2.CREDIT_LIMIT CREDIT_LIMIT
                  ON CREDIT_LIMIT.SOURCE_SYSTEM = 'CBS_SIM' AND CREDIT_LIMIT.LIMIT_REF = STG_LOAN.LIMIT_REF
                LEFT JOIN UBB_CORE2.LIMIT_HIST LIMIT_HIST
                  ON LIMIT_HIST.LIMIT_ID = CREDIT_LIMIT.LIMIT_ID AND LIMIT_HIST.LOAD_ID = (SELECT CTRL_LOAD.LOAD_ID FROM CTRL_LOAD WHERE CTRL_LOAD.SOURCE_SYSTEM = 'CBS_SIM' AND CTRL_LOAD.DATASET_NAME = 'LIMIT' AND CTRL_LOAD.BUSINESS_DATE = P_BUSINESS_DATE AND CTRL_LOAD.LOAD_STATUS IN ('VALIDATED', 'COMPLETED'))
                WHERE CTRL_LOAD.SOURCE_SYSTEM = 'CBS_SIM' AND CTRL_LOAD.DATASET_NAME = 'LOAN' AND CTRL_LOAD.BUSINESS_DATE = P_BUSINESS_DATE AND CTRL_LOAD.LOAD_STATUS IN ('VALIDATED', 'COMPLETED') AND (STG_LOAN.LIMIT_REF IS NULL OR (LIMIT_HIST.LIMIT_ID IS NOT NULL AND LIMIT_HIST.PARTNER_ID = PARTNER_HIST.PARTNER_ID))
            )
            MINUS
            SELECT LOAN_ID, LOAD_ID FROM UBB_CORE2.LOAN_HIST
        );
        ut.expect(l_missing, 'source rows that did not reach the target').to_equal(0);
    END t_ac02;

    -- AC03 (zero_rows): Every loaded loan with an undrawn amount above 0 has a credit conversion factor.
    PROCEDURE t_ac03 IS
        l_violations INTEGER;
    BEGIN
        run_load;
        SELECT COUNT(*) INTO l_violations FROM (
            SELECT LOAN_HIST.LOAN_ID FROM UBB_CORE2.LOAN_HIST JOIN UBB_CORE2.CTRL_LOAD ON CTRL_LOAD.LOAD_ID = LOAN_HIST.LOAD_ID WHERE CTRL_LOAD.SOURCE_SYSTEM = 'CBS_SIM' AND CTRL_LOAD.DATASET_NAME = 'LOAN' AND CTRL_LOAD.BUSINESS_DATE = P_BUSINESS_DATE AND LOAN_HIST.UNDRAWN_AMT > 0 AND LOAN_HIST.CREDIT_CONVERSION_FACTOR IS NULL
        );
        ut.expect(l_violations, 'rows that break AC03').to_equal(0);
    END t_ac03;

    -- AC04 (zero_rows): Every credit conversion factor in LOAN_HIST is between 0 and 1.
    PROCEDURE t_ac04 IS
        l_violations INTEGER;
    BEGIN
        run_load;
        SELECT COUNT(*) INTO l_violations FROM (
            SELECT LOAN_HIST.LOAN_ID FROM UBB_CORE2.LOAN_HIST JOIN UBB_CORE2.CTRL_LOAD ON CTRL_LOAD.LOAD_ID = LOAN_HIST.LOAD_ID WHERE CTRL_LOAD.SOURCE_SYSTEM = 'CBS_SIM' AND CTRL_LOAD.DATASET_NAME = 'LOAN' AND CTRL_LOAD.BUSINESS_DATE = P_BUSINESS_DATE AND LOAN_HIST.CREDIT_CONVERSION_FACTOR IS NOT NULL AND (LOAN_HIST.CREDIT_CONVERSION_FACTOR < 0 OR LOAN_HIST.CREDIT_CONVERSION_FACTOR > 1)
        );
        ut.expect(l_violations, 'rows that break AC04').to_equal(0);
    END t_ac04;

    -- AC05 (expected_value): The outstanding principal in LOAN_HIST equals the outstanding principal delivered in the CBS loan load of the date.
    PROCEDURE t_ac05 IS
        l_actual NUMBER;
    BEGIN
        run_load;
        SELECT * INTO l_actual FROM (
            SELECT (SELECT SUM(LOAN_HIST.PRINCIPAL_AMT) FROM UBB_CORE2.LOAN_HIST JOIN UBB_CORE2.CTRL_LOAD ON CTRL_LOAD.LOAD_ID = LOAN_HIST.LOAD_ID WHERE CTRL_LOAD.SOURCE_SYSTEM = 'CBS_SIM' AND CTRL_LOAD.DATASET_NAME = 'LOAN' AND CTRL_LOAD.BUSINESS_DATE = P_BUSINESS_DATE AND CTRL_LOAD.LOAD_STATUS IN ('VALIDATED', 'COMPLETED')) - (SELECT SUM(STG_LOAN.PRINCIPAL_AMT) FROM UBB_STAGING2.STG_LOAN JOIN UBB_CORE2.CTRL_LOAD ON CTRL_LOAD.LOAD_ID = STG_LOAN.LOAD_ID WHERE CTRL_LOAD.SOURCE_SYSTEM = 'CBS_SIM' AND CTRL_LOAD.DATASET_NAME = 'LOAN' AND CTRL_LOAD.BUSINESS_DATE = P_BUSINESS_DATE AND CTRL_LOAD.LOAD_STATUS IN ('VALIDATED', 'COMPLETED')) AS DIFF FROM DUAL
        );
        ut.expect(l_actual, 'AC05 value').to_equal(0);
    END t_ac05;

    -- AC06 (guard): Stop the run unless the business date is not empty and at midnight, and there is exactly one VALIDATED or COMPLETED CBS_SIM load of LOAN and of LIMIT for it.
    PROCEDURE t_ac06 IS
        l_rows_before INTEGER;
        l_hash_before NUMBER;
        l_rows_after  INTEGER;
        l_hash_after  NUMBER;
        l_refused     BOOLEAN := FALSE;
    BEGIN
        run_load;  -- a good run first, so "unchanged" below means something
        measure(l_rows_before, l_hash_before);
        UBB_CORE2.UT_LOAN_HIST_DATA.seed_ac06;  -- source rows that break AC06
        BEGIN
            run_load;
        EXCEPTION
            WHEN UBB_CORE2.PKG_ETL_LOAN_HIST.e_guard_failed THEN
                l_refused := TRUE;
        END;
        measure(l_rows_after, l_hash_after);
        ut.expect(l_refused, 'the load refused the source (ORA-20005)').to_be_true();
        ut.expect(l_rows_after, 'rows after the refused run (no partial snapshot)').to_equal(l_rows_before);
        ut.expect(l_hash_after, 'content after the refused run (no partial snapshot)').to_equal(l_hash_before);
    END t_ac06;

    -- AC07 (guard): Stop the run when the CBS limit snapshot load of the date has not COMPLETED in the job run log.
    PROCEDURE t_ac07 IS
        l_rows_before INTEGER;
        l_hash_before NUMBER;
        l_rows_after  INTEGER;
        l_hash_after  NUMBER;
        l_refused     BOOLEAN := FALSE;
    BEGIN
        run_load;  -- a good run first, so "unchanged" below means something
        measure(l_rows_before, l_hash_before);
        UBB_CORE2.UT_LOAN_HIST_DATA.seed_ac07;  -- source rows that break AC07
        BEGIN
            run_load;
        EXCEPTION
            WHEN UBB_CORE2.PKG_ETL_LOAN_HIST.e_guard_failed THEN
                l_refused := TRUE;
        END;
        measure(l_rows_after, l_hash_after);
        ut.expect(l_refused, 'the load refused the source (ORA-20005)').to_be_true();
        ut.expect(l_rows_after, 'rows after the refused run (no partial snapshot)').to_equal(l_rows_before);
        ut.expect(l_hash_after, 'content after the refused run (no partial snapshot)').to_equal(l_hash_before);
    END t_ac07;

    -- AC08 (guard): Stop the run when a loan of the load has no partner reference, currency, outstanding principal, undrawn amount or overdue amount.
    PROCEDURE t_ac08 IS
        l_rows_before INTEGER;
        l_hash_before NUMBER;
        l_rows_after  INTEGER;
        l_hash_after  NUMBER;
        l_refused     BOOLEAN := FALSE;
    BEGIN
        run_load;  -- a good run first, so "unchanged" below means something
        measure(l_rows_before, l_hash_before);
        UBB_CORE2.UT_LOAN_HIST_DATA.seed_ac08;  -- source rows that break AC08
        BEGIN
            run_load;
        EXCEPTION
            WHEN UBB_CORE2.PKG_ETL_LOAN_HIST.e_guard_failed THEN
                l_refused := TRUE;
        END;
        measure(l_rows_after, l_hash_after);
        ut.expect(l_refused, 'the load refused the source (ORA-20005)').to_be_true();
        ut.expect(l_rows_after, 'rows after the refused run (no partial snapshot)').to_equal(l_rows_before);
        ut.expect(l_hash_after, 'content after the refused run (no partial snapshot)').to_equal(l_hash_before);
    END t_ac08;

    -- AC09 (guard): Stop the run when the CBS partner reference of a loan does not match exactly one CRM partner valid on the business date.
    PROCEDURE t_ac09 IS
        l_rows_before INTEGER;
        l_hash_before NUMBER;
        l_rows_after  INTEGER;
        l_hash_after  NUMBER;
        l_refused     BOOLEAN := FALSE;
    BEGIN
        run_load;  -- a good run first, so "unchanged" below means something
        measure(l_rows_before, l_hash_before);
        UBB_CORE2.UT_LOAN_HIST_DATA.seed_ac09;  -- source rows that break AC09
        BEGIN
            run_load;
        EXCEPTION
            WHEN UBB_CORE2.PKG_ETL_LOAN_HIST.e_guard_failed THEN
                l_refused := TRUE;
        END;
        measure(l_rows_after, l_hash_after);
        ut.expect(l_refused, 'the load refused the source (ORA-20005)').to_be_true();
        ut.expect(l_rows_after, 'rows after the refused run (no partial snapshot)').to_equal(l_rows_before);
        ut.expect(l_hash_after, 'content after the refused run (no partial snapshot)').to_equal(l_hash_before);
    END t_ac09;

    -- AC10 (guard): Stop the run when a loan of the load has no row in UBB_CORE2.LOAN.
    PROCEDURE t_ac10 IS
        l_rows_before INTEGER;
        l_hash_before NUMBER;
        l_rows_after  INTEGER;
        l_hash_after  NUMBER;
        l_refused     BOOLEAN := FALSE;
    BEGIN
        run_load;  -- a good run first, so "unchanged" below means something
        measure(l_rows_before, l_hash_before);
        UBB_CORE2.UT_LOAN_HIST_DATA.seed_ac10;  -- source rows that break AC10
        BEGIN
            run_load;
        EXCEPTION
            WHEN UBB_CORE2.PKG_ETL_LOAN_HIST.e_guard_failed THEN
                l_refused := TRUE;
        END;
        measure(l_rows_after, l_hash_after);
        ut.expect(l_refused, 'the load refused the source (ORA-20005)').to_be_true();
        ut.expect(l_rows_after, 'rows after the refused run (no partial snapshot)').to_equal(l_rows_before);
        ut.expect(l_hash_after, 'content after the refused run (no partial snapshot)').to_equal(l_hash_before);
    END t_ac10;

    -- AC11 (guard): Stop the run when a LIMIT_REF of a loan is not found exactly once in the limit snapshot of the date for the loan's partner.
    PROCEDURE t_ac11 IS
        l_rows_before INTEGER;
        l_hash_before NUMBER;
        l_rows_after  INTEGER;
        l_hash_after  NUMBER;
        l_refused     BOOLEAN := FALSE;
    BEGIN
        run_load;  -- a good run first, so "unchanged" below means something
        measure(l_rows_before, l_hash_before);
        UBB_CORE2.UT_LOAN_HIST_DATA.seed_ac11;  -- source rows that break AC11
        BEGIN
            run_load;
        EXCEPTION
            WHEN UBB_CORE2.PKG_ETL_LOAN_HIST.e_guard_failed THEN
                l_refused := TRUE;
        END;
        measure(l_rows_after, l_hash_after);
        ut.expect(l_refused, 'the load refused the source (ORA-20005)').to_be_true();
        ut.expect(l_rows_after, 'rows after the refused run (no partial snapshot)').to_equal(l_rows_before);
        ut.expect(l_hash_after, 'content after the refused run (no partial snapshot)').to_equal(l_hash_before);
    END t_ac11;

    -- AC12 (guard): Stop the run when a loan has an undrawn amount above 0 and no credit conversion factor, or a factor outside 0 to 1.
    PROCEDURE t_ac12 IS
        l_rows_before INTEGER;
        l_hash_before NUMBER;
        l_rows_after  INTEGER;
        l_hash_after  NUMBER;
        l_refused     BOOLEAN := FALSE;
    BEGIN
        run_load;  -- a good run first, so "unchanged" below means something
        measure(l_rows_before, l_hash_before);
        UBB_CORE2.UT_LOAN_HIST_DATA.seed_ac12;  -- source rows that break AC12
        BEGIN
            run_load;
        EXCEPTION
            WHEN UBB_CORE2.PKG_ETL_LOAN_HIST.e_guard_failed THEN
                l_refused := TRUE;
        END;
        measure(l_rows_after, l_hash_after);
        ut.expect(l_refused, 'the load refused the source (ORA-20005)').to_be_true();
        ut.expect(l_rows_after, 'rows after the refused run (no partial snapshot)').to_equal(l_rows_before);
        ut.expect(l_hash_after, 'content after the refused run (no partial snapshot)').to_equal(l_hash_before);
    END t_ac12;

    -- AC13 (guard): Stop the run if any LOAN_HIST row already exists for the selected CBS loan load.
    PROCEDURE t_ac13 IS
        l_rows_before INTEGER;
        l_hash_before NUMBER;
        l_rows_after  INTEGER;
        l_hash_after  NUMBER;
        l_refused     BOOLEAN := FALSE;
    BEGIN
        run_load;  -- a good run first, so "unchanged" below means something
        measure(l_rows_before, l_hash_before);
        UBB_CORE2.UT_LOAN_HIST_DATA.seed_ac13;  -- source rows that break AC13
        BEGIN
            run_load;
        EXCEPTION
            WHEN UBB_CORE2.PKG_ETL_LOAN_HIST.e_guard_failed THEN
                l_refused := TRUE;
        END;
        measure(l_rows_after, l_hash_after);
        ut.expect(l_refused, 'the load refused the source (ORA-20005)').to_be_true();
        ut.expect(l_rows_after, 'rows after the refused run (no partial snapshot)').to_equal(l_rows_before);
        ut.expect(l_hash_after, 'content after the refused run (no partial snapshot)').to_equal(l_hash_before);
    END t_ac13;

END UT_LOAN_HIST;
/

-- Run the tests just deployed. Run this file as a script (SQL Developer F5,
-- SQLcl or SQL*Plus) so the report is printed; it needs the data package, the
-- load package and the target table to be deployed already.
SET SERVEROUTPUT ON SIZE UNLIMITED
BEGIN
    ut.run('UBB_CORE2.UT_LOAN_HIST');
END;
/
