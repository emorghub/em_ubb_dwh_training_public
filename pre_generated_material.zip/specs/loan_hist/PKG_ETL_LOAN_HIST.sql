-- ===========================================================================
-- GENERATED from mapping M_LOAN_HIST (specs/loan_hist/M_LOAN_HIST.xlsx)
--   by tools/codegen/generate.py on 2026-11-21
--   mapping fingerprint d50835be1545a80b, approved by Vladimir Andreev on 2026-11-21
-- Change the mapping workbook and regenerate - do not hand-edit this file.
-- ===========================================================================
--
-- Load package for UBB_CORE2.LOAN_HIST.
-- Conventions (see tools/codegen/templates/README.md to change them):
--   * No COMMIT inside the procedure: the caller owns the transaction (the
--     scheduler job or the developer's session commits after the call). That is also
--     what lets the utPLSQL tests roll back everything a test did.
--   * All or nothing: the procedure sets its own savepoint first and, on any
--     error, rolls back to it (never the caller's earlier work) and re-raises.
--     A failed run leaves LOAN_HIST exactly as it was - never a partial snapshot.
--   * Every parameter is mandatory; a NULL raises ORA-20001.
--   * Load strategy: append - every run only inserts; re-running the same parameters fails on the primary key
--   * Guards (AC06, AC07, AC08, AC09, AC10, AC11, AC12, AC13): checked before anything is written; one
--     that finds source rows stops the run with ORA-20005.
--   * Errors are raised, not logged here: the caller logs them (for example
--     with PKG_ETL_CONTROL.fail_run) - see tools/codegen/templates/README.md.

CREATE OR REPLACE PACKAGE UBB_CORE2.PKG_ETL_LOAN_HIST AUTHID DEFINER AS
    -- Mapping M_LOAN_HIST (fingerprint d50835be1545a80b)
    -- REQ-13, REQ-28: gross exposure = outstanding principal + undrawn amount x credit conversion factor must be calculable from CORE data only. This load keeps today

    -- Raised (ORA-20005) when a guard finds source rows; nothing was written.
    e_guard_failed EXCEPTION;
    PRAGMA EXCEPTION_INIT(e_guard_failed, -20005);

    PROCEDURE LOAD_DAY (
        P_BUSINESS_DATE IN DATE
    );
END PKG_ETL_LOAN_HIST;
/

CREATE OR REPLACE PACKAGE BODY UBB_CORE2.PKG_ETL_LOAN_HIST AS

    -- The mapping's guards: source rows that must stop the run. Checked before
    -- anything is written, so a refused run changes nothing.
    PROCEDURE check_guards(P_BUSINESS_DATE IN DATE) IS
        l_violations INTEGER;
    BEGIN
        -- AC06: Stop the run unless the business date is not empty and at midnight, and there is exactly one VALIDATED or COMPLETED CBS_SIM load of LOAN and of LIMIT for it.
        SELECT COUNT(*) INTO l_violations FROM (
            SELECT 1 AS BAD FROM DUAL WHERE P_BUSINESS_DATE IS NULL OR P_BUSINESS_DATE <> TRUNC(P_BUSINESS_DATE) OR (SELECT COUNT(*) FROM UBB_CORE2.CTRL_LOAD WHERE CTRL_LOAD.SOURCE_SYSTEM = 'CBS_SIM' AND CTRL_LOAD.DATASET_NAME = 'LOAN' AND CTRL_LOAD.BUSINESS_DATE = P_BUSINESS_DATE AND CTRL_LOAD.LOAD_STATUS IN ('VALIDATED', 'COMPLETED')) <> 1 OR (SELECT COUNT(*) FROM UBB_CORE2.CTRL_LOAD WHERE CTRL_LOAD.SOURCE_SYSTEM = 'CBS_SIM' AND CTRL_LOAD.DATASET_NAME = 'LIMIT' AND CTRL_LOAD.BUSINESS_DATE = P_BUSINESS_DATE AND CTRL_LOAD.LOAD_STATUS IN ('VALIDATED', 'COMPLETED')) <> 1
        );
        IF l_violations > 0 THEN
            RAISE_APPLICATION_ERROR(-20005, 'LOAD_DAY: guard AC06 found '
                || l_violations || ' row(s) for ' || 'P_BUSINESS_DATE=' || TO_CHAR(P_BUSINESS_DATE, 'YYYY-MM-DD')
                || ' - Stop the run unless the business date is not empty and at midnight, and there is exactly one VALIDATED or COMPLETED CBS_SIM load of LOAN and of LIMIT for it.');
        END IF;
        -- AC07: Stop the run when the CBS limit snapshot load of the date has not COMPLETED in the job run log.
        SELECT COUNT(*) INTO l_violations FROM (
            SELECT 1 AS BAD FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM UBB_CORE2.CTRL_JOB_RUN WHERE CTRL_JOB_RUN.JOB_NAME = 'LOAD_LIMIT' AND CTRL_JOB_RUN.RUN_STATUS = 'COMPLETED' AND CTRL_JOB_RUN.SOURCE_LOAD_ID IN (SELECT CTRL_LOAD.LOAD_ID FROM UBB_CORE2.CTRL_LOAD WHERE CTRL_LOAD.SOURCE_SYSTEM = 'CBS_SIM' AND CTRL_LOAD.DATASET_NAME = 'LIMIT' AND CTRL_LOAD.BUSINESS_DATE = P_BUSINESS_DATE AND CTRL_LOAD.LOAD_STATUS IN ('VALIDATED', 'COMPLETED')))
        );
        IF l_violations > 0 THEN
            RAISE_APPLICATION_ERROR(-20005, 'LOAD_DAY: guard AC07 found '
                || l_violations || ' row(s) for ' || 'P_BUSINESS_DATE=' || TO_CHAR(P_BUSINESS_DATE, 'YYYY-MM-DD')
                || ' - Stop the run when the CBS limit snapshot load of the date has not COMPLETED in the job run log.');
        END IF;
        -- AC08: Stop the run when a loan of the load has no partner reference, currency, outstanding principal, undrawn amount or overdue amount.
        SELECT COUNT(*) INTO l_violations FROM (
            SELECT STG_LOAN.LOAN_REF FROM UBB_STAGING2.STG_LOAN JOIN UBB_CORE2.CTRL_LOAD ON CTRL_LOAD.LOAD_ID = STG_LOAN.LOAD_ID WHERE CTRL_LOAD.SOURCE_SYSTEM = 'CBS_SIM' AND CTRL_LOAD.DATASET_NAME = 'LOAN' AND CTRL_LOAD.BUSINESS_DATE = P_BUSINESS_DATE AND CTRL_LOAD.LOAD_STATUS IN ('VALIDATED', 'COMPLETED') AND (STG_LOAN.CBS_PARTNER_REF IS NULL OR STG_LOAN.CURRENCY_CODE IS NULL OR STG_LOAN.PRINCIPAL_AMT IS NULL OR STG_LOAN.UNDRAWN_AMT IS NULL OR STG_LOAN.OVERDUE_AMT IS NULL)
        );
        IF l_violations > 0 THEN
            RAISE_APPLICATION_ERROR(-20005, 'LOAD_DAY: guard AC08 found '
                || l_violations || ' row(s) for ' || 'P_BUSINESS_DATE=' || TO_CHAR(P_BUSINESS_DATE, 'YYYY-MM-DD')
                || ' - Stop the run when a loan of the load has no partner reference, currency, outstanding principal, undrawn amount or overdue amount.');
        END IF;
        -- AC09: Stop the run when the CBS partner reference of a loan does not match exactly one CRM partner valid on the business date.
        SELECT COUNT(*) INTO l_violations FROM (
            SELECT STG_LOAN.LOAN_REF FROM UBB_STAGING2.STG_LOAN JOIN UBB_CORE2.CTRL_LOAD ON CTRL_LOAD.LOAD_ID = STG_LOAN.LOAD_ID WHERE CTRL_LOAD.SOURCE_SYSTEM = 'CBS_SIM' AND CTRL_LOAD.DATASET_NAME = 'LOAN' AND CTRL_LOAD.BUSINESS_DATE = P_BUSINESS_DATE AND CTRL_LOAD.LOAD_STATUS IN ('VALIDATED', 'COMPLETED') AND (SELECT COUNT(*) FROM UBB_CORE2.PARTNER_HIST JOIN UBB_CORE2.PARTNER ON PARTNER.PARTNER_ID = PARTNER_HIST.PARTNER_ID WHERE PARTNER.SOURCE_SYSTEM = 'CRM_SIM' AND PARTNER_HIST.CBS_PARTNER_REF = STG_LOAN.CBS_PARTNER_REF AND PARTNER_HIST.VALID_FROM <= P_BUSINESS_DATE AND PARTNER_HIST.VALID_TO > P_BUSINESS_DATE) <> 1
        );
        IF l_violations > 0 THEN
            RAISE_APPLICATION_ERROR(-20005, 'LOAD_DAY: guard AC09 found '
                || l_violations || ' row(s) for ' || 'P_BUSINESS_DATE=' || TO_CHAR(P_BUSINESS_DATE, 'YYYY-MM-DD')
                || ' - Stop the run when the CBS partner reference of a loan does not match exactly one CRM partner valid on the business date.');
        END IF;
        -- AC10: Stop the run when a loan of the load has no row in UBB_CORE2.LOAN.
        SELECT COUNT(*) INTO l_violations FROM (
            SELECT STG_LOAN.LOAN_REF FROM UBB_STAGING2.STG_LOAN JOIN UBB_CORE2.CTRL_LOAD ON CTRL_LOAD.LOAD_ID = STG_LOAN.LOAD_ID WHERE CTRL_LOAD.SOURCE_SYSTEM = 'CBS_SIM' AND CTRL_LOAD.DATASET_NAME = 'LOAN' AND CTRL_LOAD.BUSINESS_DATE = P_BUSINESS_DATE AND CTRL_LOAD.LOAD_STATUS IN ('VALIDATED', 'COMPLETED') AND NOT EXISTS (SELECT 1 FROM UBB_CORE2.LOAN WHERE LOAN.SOURCE_SYSTEM = 'CBS_SIM' AND LOAN.LOAN_REF = STG_LOAN.LOAN_REF)
        );
        IF l_violations > 0 THEN
            RAISE_APPLICATION_ERROR(-20005, 'LOAD_DAY: guard AC10 found '
                || l_violations || ' row(s) for ' || 'P_BUSINESS_DATE=' || TO_CHAR(P_BUSINESS_DATE, 'YYYY-MM-DD')
                || ' - Stop the run when a loan of the load has no row in UBB_CORE2.LOAN.');
        END IF;
        -- AC11: Stop the run when a LIMIT_REF of a loan is not found exactly once in the limit snapshot of the date for the loan's partner.
        SELECT COUNT(*) INTO l_violations FROM (
            SELECT STG_LOAN.LOAN_REF FROM UBB_STAGING2.STG_LOAN JOIN UBB_CORE2.CTRL_LOAD ON CTRL_LOAD.LOAD_ID = STG_LOAN.LOAD_ID WHERE CTRL_LOAD.SOURCE_SYSTEM = 'CBS_SIM' AND CTRL_LOAD.DATASET_NAME = 'LOAN' AND CTRL_LOAD.BUSINESS_DATE = P_BUSINESS_DATE AND CTRL_LOAD.LOAD_STATUS IN ('VALIDATED', 'COMPLETED') AND STG_LOAN.LIMIT_REF IS NOT NULL AND (SELECT COUNT(*) FROM UBB_CORE2.CREDIT_LIMIT JOIN UBB_CORE2.LIMIT_HIST ON LIMIT_HIST.LIMIT_ID = CREDIT_LIMIT.LIMIT_ID JOIN UBB_CORE2.PARTNER_HIST ON PARTNER_HIST.PARTNER_ID = LIMIT_HIST.PARTNER_ID AND PARTNER_HIST.VALID_FROM <= P_BUSINESS_DATE AND PARTNER_HIST.VALID_TO > P_BUSINESS_DATE JOIN UBB_CORE2.PARTNER ON PARTNER.PARTNER_ID = PARTNER_HIST.PARTNER_ID AND PARTNER.SOURCE_SYSTEM = 'CRM_SIM' WHERE CREDIT_LIMIT.SOURCE_SYSTEM = 'CBS_SIM' AND CREDIT_LIMIT.LIMIT_REF = STG_LOAN.LIMIT_REF AND PARTNER_HIST.CBS_PARTNER_REF = STG_LOAN.CBS_PARTNER_REF AND LIMIT_HIST.LOAD_ID = (SELECT CTRL_LOAD.LOAD_ID FROM UBB_CORE2.CTRL_LOAD WHERE CTRL_LOAD.SOURCE_SYSTEM = 'CBS_SIM' AND CTRL_LOAD.DATASET_NAME = 'LIMIT' AND CTRL_LOAD.BUSINESS_DATE = P_BUSINESS_DATE AND CTRL_LOAD.LOAD_STATUS IN ('VALIDATED', 'COMPLETED'))) <> 1
        );
        IF l_violations > 0 THEN
            RAISE_APPLICATION_ERROR(-20005, 'LOAD_DAY: guard AC11 found '
                || l_violations || ' row(s) for ' || 'P_BUSINESS_DATE=' || TO_CHAR(P_BUSINESS_DATE, 'YYYY-MM-DD')
                || ' - Stop the run when a LIMIT_REF of a loan is not found exactly once in the limit snapshot of the date for the loan''s partner.');
        END IF;
        -- AC12: Stop the run when a loan has an undrawn amount above 0 and no credit conversion factor, or a factor outside 0 to 1.
        SELECT COUNT(*) INTO l_violations FROM (
            SELECT STG_LOAN.LOAN_REF FROM UBB_STAGING2.STG_LOAN JOIN UBB_CORE2.CTRL_LOAD ON CTRL_LOAD.LOAD_ID = STG_LOAN.LOAD_ID WHERE CTRL_LOAD.SOURCE_SYSTEM = 'CBS_SIM' AND CTRL_LOAD.DATASET_NAME = 'LOAN' AND CTRL_LOAD.BUSINESS_DATE = P_BUSINESS_DATE AND CTRL_LOAD.LOAD_STATUS IN ('VALIDATED', 'COMPLETED') AND ((STG_LOAN.UNDRAWN_AMT > 0 AND STG_LOAN.CREDIT_CONVERSION_FACTOR IS NULL) OR STG_LOAN.CREDIT_CONVERSION_FACTOR < 0 OR STG_LOAN.CREDIT_CONVERSION_FACTOR > 1)
        );
        IF l_violations > 0 THEN
            RAISE_APPLICATION_ERROR(-20005, 'LOAD_DAY: guard AC12 found '
                || l_violations || ' row(s) for ' || 'P_BUSINESS_DATE=' || TO_CHAR(P_BUSINESS_DATE, 'YYYY-MM-DD')
                || ' - Stop the run when a loan has an undrawn amount above 0 and no credit conversion factor, or a factor outside 0 to 1.');
        END IF;
        -- AC13: Stop the run if any LOAN_HIST row already exists for the selected CBS loan load.
        SELECT COUNT(*) INTO l_violations FROM (
            SELECT LOAN_HIST.LOAN_ID FROM UBB_CORE2.LOAN_HIST JOIN UBB_CORE2.CTRL_LOAD ON CTRL_LOAD.LOAD_ID = LOAN_HIST.LOAD_ID WHERE CTRL_LOAD.SOURCE_SYSTEM = 'CBS_SIM' AND CTRL_LOAD.DATASET_NAME = 'LOAN' AND CTRL_LOAD.BUSINESS_DATE = P_BUSINESS_DATE AND CTRL_LOAD.LOAD_STATUS IN ('VALIDATED', 'COMPLETED')
        );
        IF l_violations > 0 THEN
            RAISE_APPLICATION_ERROR(-20005, 'LOAD_DAY: guard AC13 found '
                || l_violations || ' row(s) for ' || 'P_BUSINESS_DATE=' || TO_CHAR(P_BUSINESS_DATE, 'YYYY-MM-DD')
                || ' - Stop the run if any LOAN_HIST row already exists for the selected CBS loan load.');
        END IF;
    END check_guards;

    PROCEDURE LOAD_DAY (
        P_BUSINESS_DATE IN DATE
    ) IS
    BEGIN
        SAVEPOINT SP_PKG_ETL_LOAN_HIST;
        DBMS_APPLICATION_INFO.SET_MODULE('PKG_ETL_LOAN_HIST', 'LOAD_DAY');
        IF P_BUSINESS_DATE IS NULL THEN
            RAISE_APPLICATION_ERROR(-20001, 'LOAD_DAY: P_BUSINESS_DATE must not be NULL');
        END IF;

        -- Refuse the source before writing anything.
        check_guards(P_BUSINESS_DATE);

        -- Insert only. Running the same parameters twice fails on the primary key.
        INSERT INTO UBB_CORE2.LOAN_HIST (
            LOAN_ID,
            LOAD_ID,
            PARTNER_ID,
            LIMIT_ID,
            LOAN_TYPE,
            LOAN_STATUS,
            CURRENCY_CODE,
            PRINCIPAL_AMT,
            UNDRAWN_AMT,
            OVERDUE_AMT,
            INTEREST_RATE,
            START_DATE,
            MATURITY_DATE,
            CREDIT_CONVERSION_FACTOR,
            CREATED_AT
        )
        SELECT LOAN.LOAN_ID                      AS LOAN_ID,
               STG_LOAN.LOAD_ID                  AS LOAD_ID,
               PARTNER_HIST.PARTNER_ID           AS PARTNER_ID,
               CREDIT_LIMIT.LIMIT_ID             AS LIMIT_ID,
               STG_LOAN.LOAN_TYPE                AS LOAN_TYPE,
               STG_LOAN.LOAN_STATUS              AS LOAN_STATUS,
               STG_LOAN.CURRENCY_CODE            AS CURRENCY_CODE,
               STG_LOAN.PRINCIPAL_AMT            AS PRINCIPAL_AMT,
               STG_LOAN.UNDRAWN_AMT              AS UNDRAWN_AMT,
               STG_LOAN.OVERDUE_AMT              AS OVERDUE_AMT,
               STG_LOAN.INTEREST_RATE            AS INTEREST_RATE,
               STG_LOAN.START_DATE               AS START_DATE,
               STG_LOAN.MATURITY_DATE            AS MATURITY_DATE,
               STG_LOAN.CREDIT_CONVERSION_FACTOR AS CREDIT_CONVERSION_FACTOR,
               SYSTIMESTAMP                      AS CREATED_AT
        FROM UBB_STAGING2.STG_LOAN STG_LOAN
        JOIN UBB_CORE2.CTRL_LOAD CTRL_LOAD
          ON CTRL_LOAD.LOAD_ID = STG_LOAN.LOAD_ID
        JOIN UBB_CORE2.LOAN LOAN
          ON LOAN.SOURCE_SYSTEM = 'CBS_SIM' AND LOAN.LOAN_REF = STG_LOAN.LOAN_REF
        JOIN UBB_CORE2.PARTNER_HIST PARTNER_HIST
          ON PARTNER_HIST.CBS_PARTNER_REF = STG_LOAN.CBS_PARTNER_REF AND PARTNER_HIST.VALID_FROM <= P_BUSINESS_DATE AND PARTNER_HIST.VALID_TO > P_BUSINESS_DATE
        JOIN UBB_CORE2.PARTNER PARTNER
          ON PARTNER.PARTNER_ID = PARTNER_HIST.PARTNER_ID AND PARTNER.SOURCE_SYSTEM = 'CRM_SIM'
        LEFT JOIN UBB_CORE2.CREDIT_LIMIT CREDIT_LIMIT
          ON CREDIT_LIMIT.SOURCE_SYSTEM = 'CBS_SIM' AND CREDIT_LIMIT.LIMIT_REF = STG_LOAN.LIMIT_REF
        LEFT JOIN UBB_CORE2.LIMIT_HIST LIMIT_HIST
          ON LIMIT_HIST.LIMIT_ID = CREDIT_LIMIT.LIMIT_ID AND LIMIT_HIST.LOAD_ID = (SELECT CTRL_LOAD.LOAD_ID FROM CTRL_LOAD WHERE CTRL_LOAD.SOURCE_SYSTEM = 'CBS_SIM' AND CTRL_LOAD.DATASET_NAME = 'LIMIT' AND CTRL_LOAD.BUSINESS_DATE = P_BUSINESS_DATE AND CTRL_LOAD.LOAD_STATUS IN ('VALIDATED', 'COMPLETED'))
        WHERE CTRL_LOAD.SOURCE_SYSTEM = 'CBS_SIM' AND CTRL_LOAD.DATASET_NAME = 'LOAN' AND CTRL_LOAD.BUSINESS_DATE = P_BUSINESS_DATE AND CTRL_LOAD.LOAD_STATUS IN ('VALIDATED', 'COMPLETED') AND (STG_LOAN.LIMIT_REF IS NULL OR (LIMIT_HIST.LIMIT_ID IS NOT NULL AND LIMIT_HIST.PARTNER_ID = PARTNER_HIST.PARTNER_ID));

        DBMS_APPLICATION_INFO.SET_MODULE(NULL, NULL);
    EXCEPTION
        WHEN OTHERS THEN
            -- Undo this run's own work only; the caller's transaction stays open.
            ROLLBACK TO SAVEPOINT SP_PKG_ETL_LOAN_HIST;
            DBMS_APPLICATION_INFO.SET_MODULE(NULL, NULL);
            RAISE;
    END LOAD_DAY;

END PKG_ETL_LOAN_HIST;
/
