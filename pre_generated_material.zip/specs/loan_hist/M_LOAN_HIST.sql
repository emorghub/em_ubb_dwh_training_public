-- ===========================================================================
-- GENERATED from mapping M_LOAN_HIST (specs/loan_hist/M_LOAN_HIST.xlsx)
--   by tools/codegen/generate.py on 2026-11-21
--   mapping fingerprint d50835be1545a80b, approved by Vladimir Andreev on 2026-11-21
-- Change the mapping workbook and regenerate - do not hand-edit this file.
-- ===========================================================================
--
-- Brings the existing UBB_CORE2.LOAN_HIST in line with the mapping. Written by comparing
-- the mapping with the table script in sql/ on 2026-11-21; deploy it instead of
-- LOAN_HIST.sql, which holds the full definition.
-- Only safe, additive changes are executed. Anything that could lose data or
-- fail on existing rows is listed at the bottom for a person to decide.

ALTER TABLE UBB_CORE2.LOAN_HIST ADD (
    CREDIT_CONVERSION_FACTOR NUMBER(9,6)
);
COMMENT ON COLUMN UBB_CORE2.LOAN_HIST.CREDIT_CONVERSION_FACTOR IS 'Credit conversion factor: Factor, as a fraction between 0 and 1, by which the undrawn amount of the loan is converted into an exposure equivalent. Gross exposure = outstanding principal + undrawn amount x this factor.';
