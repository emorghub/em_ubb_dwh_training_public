-- ===========================================================================
-- Test data for UT_LOAN_HIST (mapping M_LOAN_HIST).
-- Written ONCE by tools/codegen/generate.py on 2026-11-21 as a starting
-- point, then owned by the developer: regenerating the tests never overwrites
-- this file. Completed by hand on 2026-11-21: placeholders replaced, cases added.
--
-- Needs (run by a user who may grant on the staging schema):
--   GRANT INSERT ON UBB_STAGING2.STG_LOAN TO UBB_CORE2;
--   GRANT INSERT ON UBB_CORE2.CTRL_LOAD TO UBB_CORE2;
--   GRANT INSERT ON UBB_CORE2.LOAN TO UBB_CORE2;
--   GRANT INSERT ON UBB_CORE2.PARTNER_HIST TO UBB_CORE2;
--   GRANT INSERT ON UBB_CORE2.PARTNER TO UBB_CORE2;
--   GRANT INSERT ON UBB_CORE2.CREDIT_LIMIT TO UBB_CORE2;
--   GRANT INSERT ON UBB_CORE2.LIMIT_HIST TO UBB_CORE2;
-- Everything seed inserts is rolled back after each test by utPLSQL.
--
-- Precondition: UBB_STAGING2.STG_LOAN has the column CREDIT_CONVERSION_FACTOR
-- (staging change of CR-ECB-001) and UBB_CORE2.LOAN_HIST has it too
-- (M_LOAN_HIST.sql), otherwise this package does not compile or run.
--
-- All test keys are UT-prefixed or in the 9000xx ID range, on the business date
-- 2000-01-01, so they cannot meet real data.
--
-- What seed holds (loan load 900001, limit load 900002, partner load 900003):
--   UT-LOAN-001  partner P001, limit UT-LIM-001, undrawn > 0, factor 0.5
--   UT-LOAN-002  partner P002 (person), no limit (left join), undrawn 0, no factor, overdue > 0
--   UT-LOAN-003  partner P003 with an expired history row (the date filter picks the current
--                one), limit UT-LIM-002, factor 1 (upper bound)
--   UT-LOAN-004  partner P001 again, shares limit UT-LIM-001, factor 0 (lower bound)
--   Not loaded, because outside the Filter: UT-LOAN-099 in a FAILED load of the same date,
--   and UT-LOAN-001 in a COMPLETED load of the next day.
-- ===========================================================================

CREATE OR REPLACE PACKAGE UBB_CORE2.UT_LOAN_HIST_DATA AS
    -- The parameter values every test runs the load with. Pick values no real
    -- staging data uses, so the tests do not depend on what happens to be loaded.
    P_BUSINESS_DATE CONSTANT DATE := DATE '2000-01-01';

    PROCEDURE seed;

    -- Source rows that break guard AC06. Only its test inserts them, after seed.
    PROCEDURE seed_ac06;

    -- Source rows that break guard AC07. Only its test inserts them, after seed.
    PROCEDURE seed_ac07;

    -- Source rows that break guard AC08. Only its test inserts them, after seed.
    PROCEDURE seed_ac08;

    -- Source rows that break guard AC09. Only its test inserts them, after seed.
    PROCEDURE seed_ac09;

    -- Source rows that break guard AC10. Only its test inserts them, after seed.
    PROCEDURE seed_ac10;

    -- Source rows that break guard AC11. Only its test inserts them, after seed.
    PROCEDURE seed_ac11;

    -- Source rows that break guard AC12. Only its test inserts them, after seed.
    PROCEDURE seed_ac12;

    -- Source rows that break guard AC13. Only its test inserts them, after seed.
    PROCEDURE seed_ac13;
END UT_LOAN_HIST_DATA;
/

CREATE OR REPLACE PACKAGE BODY UBB_CORE2.UT_LOAN_HIST_DATA AS

    c_loan_load    CONSTANT NUMBER := 900001;  -- CBS_SIM LOAN load of the business date
    c_limit_load   CONSTANT NUMBER := 900002;  -- CBS_SIM LIMIT load of the business date
    c_partner_load CONSTANT NUMBER := 900003;  -- CRM_SIM PARTNER load the partner history belongs to

    PROCEDURE ins_load(p_load_id IN NUMBER, p_system IN VARCHAR2, p_dataset IN VARCHAR2,
                       p_date IN DATE, p_status IN VARCHAR2) IS
    BEGIN
        INSERT INTO UBB_CORE2.CTRL_LOAD (LOAD_ID, SOURCE_SYSTEM, DATASET_NAME, BUSINESS_DATE, LOAD_STATUS)
        VALUES (p_load_id, p_system, p_dataset, p_date, p_status);
    END ins_load;

    PROCEDURE ins_partner(p_id IN NUMBER, p_ref IN VARCHAR2) IS
    BEGIN
        INSERT INTO UBB_CORE2.PARTNER (PARTNER_ID, SOURCE_SYSTEM, PARTNER_REF)
        VALUES (p_id, 'CRM_SIM', p_ref);
    END ins_partner;

    PROCEDURE ins_partner_hist(p_id IN NUMBER, p_from IN DATE, p_to IN DATE, p_is_current IN VARCHAR2,
                               p_name IN VARCHAR2, p_type IN VARCHAR2, p_cbs_ref IN VARCHAR2) IS
    BEGIN
        INSERT INTO UBB_CORE2.PARTNER_HIST (PARTNER_ID, VALID_FROM, VALID_TO, IS_CURRENT,
                                            PARTNER_NAME, PARTNER_TYPE, CBS_PARTNER_REF, LOAD_ID)
        VALUES (p_id, p_from, p_to, p_is_current, p_name, p_type, p_cbs_ref, c_partner_load);
    END ins_partner_hist;

    PROCEDURE ins_core_loan(p_id IN NUMBER, p_ref IN VARCHAR2) IS
    BEGIN
        INSERT INTO UBB_CORE2.LOAN (LOAN_ID, SOURCE_SYSTEM, LOAN_REF)
        VALUES (p_id, 'CBS_SIM', p_ref);
    END ins_core_loan;

    PROCEDURE ins_stg_loan(p_load_id IN NUMBER, p_loan_ref IN VARCHAR2, p_partner_ref IN VARCHAR2,
                           p_limit_ref IN VARCHAR2, p_type IN VARCHAR2, p_status IN VARCHAR2,
                           p_currency IN VARCHAR2, p_principal IN NUMBER, p_undrawn IN NUMBER,
                           p_overdue IN NUMBER, p_rate IN NUMBER, p_start IN DATE, p_maturity IN DATE,
                           p_ccf IN NUMBER) IS
    BEGIN
        INSERT INTO UBB_STAGING2.STG_LOAN (
            LOAD_ID, LOAN_REF, CBS_PARTNER_REF, LIMIT_REF, LOAN_TYPE, LOAN_STATUS, CURRENCY_CODE,
            PRINCIPAL_AMT, UNDRAWN_AMT, OVERDUE_AMT, INTEREST_RATE, START_DATE, MATURITY_DATE,
            CREDIT_CONVERSION_FACTOR
        ) VALUES (
            p_load_id, p_loan_ref, p_partner_ref, p_limit_ref, p_type, p_status, p_currency,
            p_principal, p_undrawn, p_overdue, p_rate, p_start, p_maturity,
            p_ccf
        );
    END ins_stg_loan;

    PROCEDURE seed IS
    BEGIN
        -- UBB_CORE2.CTRL_LOAD - inner join: CTRL_LOAD.LOAD_ID = STG_LOAN.LOAD_ID
        ins_load(c_loan_load,    'CBS_SIM', 'LOAN',    P_BUSINESS_DATE,     'COMPLETED');
        ins_load(c_limit_load,   'CBS_SIM', 'LIMIT',   P_BUSINESS_DATE,     'COMPLETED');
        ins_load(c_partner_load, 'CRM_SIM', 'PARTNER', P_BUSINESS_DATE,     'COMPLETED');
        -- outside the Filter: a failed loan load of the same date, and a loan load of the next day
        ins_load(900004,         'CBS_SIM', 'LOAN',    P_BUSINESS_DATE,     'FAILED');
        ins_load(900005,         'CBS_SIM', 'LOAN',    P_BUSINESS_DATE + 1, 'COMPLETED');

        -- UBB_CORE2.CTRL_JOB_RUN - guard AC07 needs the limit load to have COMPLETED in the run log.
        -- The job is reference data; added only when the database does not have it yet.
        MERGE INTO UBB_CORE2.CTRL_JOB j
        USING (SELECT 'LOAD_LIMIT' AS JOB_NAME FROM DUAL) s
           ON (j.JOB_NAME = s.JOB_NAME)
         WHEN NOT MATCHED THEN
            INSERT (JOB_NAME, DATASET_NAME, SOURCE_SYSTEM) VALUES ('LOAD_LIMIT', 'LIMIT', 'CBS_SIM');
        INSERT INTO UBB_CORE2.CTRL_JOB_RUN (RUN_ID, JOB_NAME, BUSINESS_DATE, SOURCE_LOAD_ID, RUN_STATUS)
        VALUES (900001, 'LOAD_LIMIT', P_BUSINESS_DATE, c_limit_load, 'COMPLETED');

        -- UBB_CORE2.PARTNER - inner join: PARTNER.PARTNER_ID = PARTNER_HIST.PARTNER_ID AND PARTNER.SOURCE_SYSTEM = 'CRM_SIM'
        ins_partner(900001, 'UT-CRM-P001');
        ins_partner(900002, 'UT-CRM-P002');
        ins_partner(900003, 'UT-CRM-P003');

        -- UBB_CORE2.PARTNER_HIST - inner join on the CBS partner reference and the period [from, to)
        ins_partner_hist(900001, P_BUSINESS_DATE - 365, DATE '9999-12-31', 'Y',
                         'UT Nordic Trading EOOD', 'COMPANY', 'UT-CBS-P001');
        ins_partner_hist(900002, P_BUSINESS_DATE - 365, DATE '9999-12-31', 'Y',
                         'UT Ivan Petrov', 'PERSON', 'UT-CBS-P002');
        -- P003: an expired version (VALID_TO = the day it was replaced) and the current one;
        -- a load that ignored the period would join both and break the key
        ins_partner_hist(900003, P_BUSINESS_DATE - 730, P_BUSINESS_DATE - 365, 'N',
                         'UT Balkan Logistics Ltd', 'COMPANY', 'UT-CBS-P003');
        ins_partner_hist(900003, P_BUSINESS_DATE - 365, DATE '9999-12-31', 'Y',
                         'UT Balkan Logistics AD', 'COMPANY', 'UT-CBS-P003');

        -- UBB_CORE2.CREDIT_LIMIT - left join: CREDIT_LIMIT.SOURCE_SYSTEM = 'CBS_SIM' AND CREDIT_LIMIT.LIMIT_REF = STG_LOAN.LIMIT_REF
        INSERT INTO UBB_CORE2.CREDIT_LIMIT (LIMIT_ID, SOURCE_SYSTEM, LIMIT_REF)
        VALUES (900001, 'CBS_SIM', 'UT-LIM-001');
        INSERT INTO UBB_CORE2.CREDIT_LIMIT (LIMIT_ID, SOURCE_SYSTEM, LIMIT_REF)
        VALUES (900002, 'CBS_SIM', 'UT-LIM-002');

        -- UBB_CORE2.LIMIT_HIST - left join: the limit snapshot of the same business date, for the loan's partner
        INSERT INTO UBB_CORE2.LIMIT_HIST (LIMIT_ID, LOAD_ID, PARTNER_ID, LIMIT_TYPE, LIMIT_STATUS,
                                          CURRENCY_CODE, APPROVED_AMT, UTILIZED_AMT)
        VALUES (900001, c_limit_load, 900001, 'REVOLVING', 'ACTIVE', 'EUR', 500000.00, 250000.00);
        INSERT INTO UBB_CORE2.LIMIT_HIST (LIMIT_ID, LOAD_ID, PARTNER_ID, LIMIT_TYPE, LIMIT_STATUS,
                                          CURRENCY_CODE, APPROVED_AMT, UTILIZED_AMT)
        VALUES (900002, c_limit_load, 900003, 'TERM', 'ACTIVE', 'USD', 300000.00, 0);

        -- UBB_CORE2.LOAN - inner join: LOAN.SOURCE_SYSTEM = 'CBS_SIM' AND LOAN.LOAN_REF = STG_LOAN.LOAN_REF
        ins_core_loan(900001, 'UT-LOAN-001');
        ins_core_loan(900002, 'UT-LOAN-002');
        ins_core_loan(900003, 'UT-LOAN-003');
        ins_core_loan(900004, 'UT-LOAN-004');
        ins_core_loan(900099, 'UT-LOAN-099');

        -- UBB_STAGING2.STG_LOAN - driving table: each row that passes the Filter becomes one target row
        -- ref, partner, limit, type, status, ccy, principal, undrawn, overdue, rate, start, maturity, factor
        ins_stg_loan(c_loan_load, 'UT-LOAN-001', 'UT-CBS-P001', 'UT-LIM-001', 'TERM_LOAN', 'ACTIVE', 'EUR',
                     250000.00, 50000.00, 0, 4.250000, P_BUSINESS_DATE - 730, P_BUSINESS_DATE + 1460, 0.5);
        ins_stg_loan(c_loan_load, 'UT-LOAN-002', 'UT-CBS-P002', NULL, 'CONSUMER', 'ACTIVE', 'BGN',
                     12000.50, 0, 300.25, 7.900000, P_BUSINESS_DATE - 365, P_BUSINESS_DATE + 1095, NULL);
        ins_stg_loan(c_loan_load, 'UT-LOAN-003', 'UT-CBS-P003', 'UT-LIM-002', 'OVERDRAFT', 'ACTIVE', 'USD',
                     0, 100000.00, 0, 5.500000, NULL, NULL, 1);
        ins_stg_loan(c_loan_load, 'UT-LOAN-004', 'UT-CBS-P001', 'UT-LIM-001', 'TERM_LOAN', 'ACTIVE', 'EUR',
                     5000.00, 20000.00, 0, 4.000000, P_BUSINESS_DATE - 30, P_BUSINESS_DATE + 335, 0);
        -- outside the Filter (load not COMPLETED): joins everywhere, so only the Filter keeps it out
        ins_stg_loan(900004, 'UT-LOAN-099', 'UT-CBS-P001', NULL, 'TERM_LOAN', 'ACTIVE', 'EUR',
                     999999.99, 0, 0, 3.000000, P_BUSINESS_DATE - 100, P_BUSINESS_DATE + 100, NULL);
        -- outside the Filter (other business date): the same loan, the next day
        ins_stg_loan(900005, 'UT-LOAN-001', 'UT-CBS-P001', 'UT-LIM-001', 'TERM_LOAN', 'ACTIVE', 'EUR',
                     240000.00, 60000.00, 0, 4.250000, P_BUSINESS_DATE - 730, P_BUSINESS_DATE + 1460, 0.5);
    END seed;

    -- AC06: a second COMPLETED CBS loan load for the same date: not exactly one.
    PROCEDURE seed_ac06 IS
    BEGIN
        ins_load(900011, 'CBS_SIM', 'LOAN', P_BUSINESS_DATE, 'COMPLETED');
    END seed_ac06;

    -- AC07: the limit load is there, but its job run did not complete.
    PROCEDURE seed_ac07 IS
    BEGIN
        UPDATE UBB_CORE2.CTRL_JOB_RUN SET RUN_STATUS = 'FAILED' WHERE RUN_ID = 900001;
    END seed_ac07;

    -- AC08: a loan without outstanding principal; everything else about it is valid.
    PROCEDURE seed_ac08 IS
    BEGIN
        ins_core_loan(900081, 'UT-LOAN-081');
        ins_stg_loan(c_loan_load, 'UT-LOAN-081', 'UT-CBS-P002', NULL, 'CONSUMER', 'ACTIVE', 'BGN',
                     NULL, 0, 0, 7.900000, NULL, NULL, NULL);
    END seed_ac08;

    -- AC09: a loan whose partner reference matches no partner, and a reference that matches two.
    PROCEDURE seed_ac09 IS
    BEGIN
        ins_core_loan(900091, 'UT-LOAN-091');
        ins_stg_loan(c_loan_load, 'UT-LOAN-091', 'UT-CBS-P-UNKNOWN', NULL, 'CONSUMER', 'ACTIVE', 'BGN',
                     1000.00, 0, 0, 7.900000, NULL, NULL, NULL);
        -- a second partner valid on the date with the CBS reference of P002 (UT-LOAN-002 becomes ambiguous)
        ins_partner(900005, 'UT-CRM-P005');
        ins_partner_hist(900005, P_BUSINESS_DATE - 365, DATE '9999-12-31', 'Y',
                         'UT Duplicate Partner', 'PERSON', 'UT-CBS-P002');
    END seed_ac09;

    -- AC10: a loan with no row in UBB_CORE2.LOAN (its partner is fine).
    PROCEDURE seed_ac10 IS
    BEGIN
        ins_stg_loan(c_loan_load, 'UT-LOAN-101', 'UT-CBS-P002', NULL, 'CONSUMER', 'ACTIVE', 'BGN',
                     1000.00, 0, 0, 7.900000, NULL, NULL, NULL);
    END seed_ac10;

    -- AC11: a loan whose limit exists, but in the limit snapshot belongs to another partner (P003, not P001).
    PROCEDURE seed_ac11 IS
    BEGIN
        ins_core_loan(900111, 'UT-LOAN-111');
        ins_stg_loan(c_loan_load, 'UT-LOAN-111', 'UT-CBS-P001', 'UT-LIM-002', 'TERM_LOAN', 'ACTIVE', 'USD',
                     1000.00, 0, 0, 5.500000, NULL, NULL, NULL);
    END seed_ac11;

    -- AC12: undrawn amount above 0 without a factor, and a factor above 1.
    PROCEDURE seed_ac12 IS
    BEGIN
        ins_core_loan(900121, 'UT-LOAN-121');
        ins_core_loan(900122, 'UT-LOAN-122');
        ins_stg_loan(c_loan_load, 'UT-LOAN-121', 'UT-CBS-P002', NULL, 'OVERDRAFT', 'ACTIVE', 'BGN',
                     1000.00, 1000.00, 0, 7.900000, NULL, NULL, NULL);
        ins_stg_loan(c_loan_load, 'UT-LOAN-122', 'UT-CBS-P002', NULL, 'OVERDRAFT', 'ACTIVE', 'BGN',
                     1000.00, 1000.00, 0, 7.900000, NULL, NULL, 1.5);
    END seed_ac12;

    -- AC13: nothing to add. The test runs the load once before this procedure, so a snapshot of
    -- the selected loan load already exists and the second run must be refused.
    PROCEDURE seed_ac13 IS
    BEGIN
        NULL;
    END seed_ac13;

END UT_LOAN_HIST_DATA;
/
