#!/bin/sh
# Checks every file of this package against SHA256SUMS. Works on Linux and macOS.
cd "$(dirname "$0")" || exit 2
if command -v sha256sum >/dev/null 2>&1; then
    sha256sum -c SHA256SUMS
elif command -v shasum >/dev/null 2>&1; then
    shasum -a 256 -c SHA256SUMS
else
    echo "sha256sum or shasum is needed" >&2
    exit 2
fi
