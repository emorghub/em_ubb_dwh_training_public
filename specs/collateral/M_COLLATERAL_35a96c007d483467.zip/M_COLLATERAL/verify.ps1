# Checks every file of this package against SHA256SUMS. Windows PowerShell 5.1 and PowerShell 7.
$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot
$bad = 0
foreach ($line in Get-Content -LiteralPath 'SHA256SUMS') {
    if ($line -notmatch '^([0-9a-f]{64})  (.+)$') { continue }
    $expected = $Matches[1]
    $file = $Matches[2]
    if (-not (Test-Path -LiteralPath $file)) { Write-Host "MISSING  $file"; $bad++; continue }
    $actual = (Get-FileHash -LiteralPath $file -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($actual -eq $expected) { Write-Host "OK       $file" } else { Write-Host "FAILED   $file"; $bad++ }
}
if ($bad -gt 0) { Write-Host "$bad file(s) differ or are missing."; exit 1 }
Write-Host 'All files match.'
