DEPLOYMENT PACKAGE - M_COLLATERAL

Mapping fingerprint : 35a96c007d483467
Approved by         : Emil Angelov on 2026-11-27
Change request      : CR-ECB-001
Target              : UBB_CORE2.COLLATERAL_HIST
Load procedure      : UBB_CORE2.PKG_ETL_COLLATERAL.LOAD_DAY
Built on            : 2026-11-27 from git commit 34844ee4cc5e

This package holds files only. Nothing in it has been run, and nothing in it opens a
database connection by itself: a developer reviews every file and runs it by hand.

1. Verify the package (after copying it to the other machine)
   Linux / macOS : sh verify.sh
   Windows       : powershell -ExecutionPolicy Bypass -File verify.ps1
   Every line must say OK.

2. Read the runbook
   RUNBOOK.md (in this folder, next to this file)
   It lists the steps in order, with the schema to connect as, the parameters, the expected
   result and the stop condition of each, and what is outside this package (open items).
   Paths in the runbook are relative to this folder: run every command from here.

3. Run the SQL files
   Needs SQLcl (Java 11 or later) or SQL*Plus, a network route to the database and the
   database users the runbook names. Never put a password on the command line; let the
   tool ask for it.

   Linux, macOS and Windows alike:   sql UBB_CORE2@//host:1521/SERVICE
                                     (SQL*Plus: sqlplus UBB_CORE2@//host:1521/SERVICE)

   then, at the SQL prompt, one file at a time, from this folder, with the arguments the
   runbook gives, for example:       @preflight/FILE.sql TEST
   All files are UTF-8 with LF line endings. If SQL*Plus shows garbled characters, set
   NLS_LANG=.AL32UTF8 first (Windows: chcp 65001 as well).

4. After deployment
   A developer exports the changed table and package scripts into the repository's sql/
   folder by hand, so the repository matches the database.

Unpacking next to other packages
--------------------------------
Everything is inside one folder named M_COLLATERAL, with at most one level of folders below
it, so the packages of different mappings can be unpacked into the same directory without
overwriting each other. Unpacking a newer package of the same mapping into the same
directory overwrites the older one file by file and can leave files of the old version
behind: delete the old M_COLLATERAL folder first (MANIFEST.json holds the fingerprint).

Files
-----
  RUNBOOK.md                                   runbook  - the runbook
  staging/STG_COLLATERAL.sql                   staging  - before the mapping's own DDL; run by the staging schema owner or a DBA
  grants/grants_select.sql                     grants  - run by the owner of the source schema or a DBA
  grants/grants_test_only_insert.sql           grants (TEST only)  - test environment only
  preflight/DEPLOY_M_COLLATERAL_PREFLIGHT_1_BEFORE_DDL.sql preflight_1  - read-only checks
  ddl/M_COLLATERAL.sql                         table_change  - the table exists: this replaces the full CREATE TABLE script
  code/PKG_ETL_COLLATERAL.sql                  package
  test/UT_COLLATERAL_HIST_DATA.sql             test_data (TEST only)  - test environment only
  test/UT_COLLATERAL_HIST.sql                  tests (TEST only)  - test environment only; ends by running the tests
  preflight/DEPLOY_M_COLLATERAL_PREFLIGHT_2_BEFORE_RUN.sql preflight_2  - read-only checks

Not in this package (see the runbook, "Open items"): anything the repository does not hold,
such as a wrapper or scheduler change, a loader, or a configuration value.
