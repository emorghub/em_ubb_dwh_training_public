-- Grants for mapping M_COLLATERAL (mapping fingerprint 35a96c007d483467).
-- Written by tools/codegen/package_deployment.py. Run by the owner of the source schema or a DBA;
-- the load package is definer-rights, so each grant must be direct, not through a role.
-- TEST ENVIRONMENT ONLY: the test data package inserts into these tables. Never run in production.

GRANT INSERT ON UBB_STAGING2.STG_COLLATERAL TO UBB_CORE2;
